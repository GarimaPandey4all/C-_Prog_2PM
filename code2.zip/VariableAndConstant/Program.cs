﻿using System;

namespace VariableAndConstant
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            a = 50;

            Console.WriteLine(a);

            const float pi = 3.14f; // constant = fixed value

            // pi = 56.78f; // error

            Console.WriteLine(pi);   
        }
    }
}
