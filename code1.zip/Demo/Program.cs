﻿//using System; // namespace: is a collection of predefined classes

namespace Demo
{
    class Program
    {
        //void (null or empty) - return type
        static void Main(string args[]) // Main(): entry point or initial point of every C# program
        {
            //identifier() - function presentation

            System.Console.WriteLine("Brain Mentors!"); // print output on the output screen
            /*
            string: more than one character
             'a' - char
             "ab" - string
             */
        }
    }
}
