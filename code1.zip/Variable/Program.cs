﻿using System;

namespace Variable
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variable: it is a container and vary / change 

            int a = 10, b = 20, c; // a, b, c - declare/create the variables and a, b - initialize/define/assign

            c = a + b; // c - initialization

            Console.WriteLine("Addition is: " +c); // + concatenation/joining

        }
    }
}
